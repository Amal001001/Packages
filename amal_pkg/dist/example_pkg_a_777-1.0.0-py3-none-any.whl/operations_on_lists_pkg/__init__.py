from .main import MyClass
